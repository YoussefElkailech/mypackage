def sqr(x):
    return x*x
