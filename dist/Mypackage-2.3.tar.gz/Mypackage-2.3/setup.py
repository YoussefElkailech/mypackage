from setuptools import setup, find_packages
setup(
    name = "Mypackage",
    version = '2.3',
    license = "MIT",
    author = 'Youssef El Kailech',
    author_email = 'y.elkailech@gmail.com'
)